package fuzzycat.functiongrapher.grapher.parser;

public class Error {
	
	public Error() {
		
	}
	
	public void makeError(String msg) {
		System.out.println(msg);
	}
}
