package fuzzycat.functiongrapher.grapher.expression;

public class Variable extends Number {

	public Variable() {
		super(0.0);
	}

	public void set(double num) {
		this.num = num;
	}
}
